module.exports = {
  baseUrl: "http://chasetoch-414f28877725.herokuapp.com/",
};
